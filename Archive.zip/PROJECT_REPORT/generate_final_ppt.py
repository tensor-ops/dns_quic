"""
Final PPT Generator — In-Place Template Upgrade
Updates media_1795105985798_efac268b.pptx in-place to produce:
/Users/paru/paru/projects/RM/PROJECT_REPORT/FINAL_PRESENTATION.pptx

Preserves:
- Slide 1: Original Title slide with IIITA Crest Logo, team details, typography.
- Slide 14: Original Thank You slide.
Rewrites Slides 2 through 13 with the exact 14-slide defense deck structure,
real experimental data, metric cards, styled comparison tables, and visual callouts.
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

TEMPLATE_PATH = '/Users/paru/.gemini/antigravity/brain/e5656d74-4c58-414e-8d77-9eb5475a671c/.user_uploaded/media_1795105985798_efac268b.pptx'
OUTPUT_PATH   = '/Users/paru/paru/projects/RM/PROJECT_REPORT/FINAL_PRESENTATION.pptx'

# Design Tokens matching template
C_NAVY   = RGBColor(0x14, 0x28, 0x4B)   # Headings / Primary dark
C_TEAL   = RGBColor(0x0F, 0x7C, 0x8A)   # Accent teal
C_LTEAL  = RGBColor(0x8F, 0xD3, 0xDB)   # Highlight light teal
C_BODY   = RGBColor(0x1E, 0x29, 0x3B)   # Body dark slate
C_GREY   = RGBColor(0x5A, 0x6B, 0x80)   # Secondary grey
C_WHITE  = RGBColor(0xFF, 0xFF, 0xFF)
C_DKGRY  = RGBColor(0x44, 0x44, 0x44)
C_GRN    = RGBColor(0x16, 0xA3, 0x4A)   # Success / High accuracy
C_RED    = RGBColor(0xDC, 0x26, 0x26)   # Alert / Degradation
C_AMBER  = RGBColor(0xD9, 0x77, 0x06)   # Intermediate warning
C_BG_BOX = RGBColor(0xF1, 0xF5, 0xF9)   # Light card background
C_BG_ROW = RGBColor(0xF8, 0xFA, 0xFC)   # Table alternating row

W = Inches(10)
H = Inches(5.625)

def clear_slide(slide):
    spTree = slide.shapes._spTree
    for child in list(spTree)[2:]:
        spTree.remove(child)

def add_rect(slide, left, top, width, height, fill_color, line_color=None, line_width=None):
    shape = slide.shapes.add_shape(1, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if line_color:
        shape.line.color.rgb = line_color
        if line_width:
            shape.line.width = line_width
    else:
        shape.line.fill.background()
    return shape

def add_textbox(slide, text, left, top, width, height,
                font_size=11, bold=False, color=C_BODY,
                align=PP_ALIGN.LEFT, wrap=True, italic=False):
    txb = slide.shapes.add_textbox(left, top, width, height)
    tf  = txb.text_frame
    tf.word_wrap = wrap
    tf.margin_left = Inches(0.04)
    tf.margin_right = Inches(0.04)
    tf.margin_top = Inches(0.04)
    tf.margin_bottom = Inches(0.04)
    p   = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txb

def add_header(slide, title, subtitle=None):
    add_rect(slide, Inches(0), Inches(0), W, Inches(0.72), C_NAVY)
    add_rect(slide, Inches(0), Inches(0.72), W, Inches(0.05), C_TEAL)
    add_textbox(slide, title, Inches(0.35), Inches(0.12), Inches(9.3), Inches(0.52),
                font_size=19, bold=True, color=C_WHITE)
    if subtitle:
        add_textbox(slide, subtitle, Inches(0.38), Inches(0.78), Inches(9.2), Inches(0.28),
                    font_size=9.5, color=C_GREY)

def add_footer(slide, slide_num):
    add_rect(slide, Inches(0), Inches(5.38), W, Inches(0.245), C_NAVY)
    add_textbox(slide, 'DNS in the QUIC Crowd: Can Modern Encrypted DNS Hide Among Encrypted Web Traffic? | IIIT Allahabad',
                Inches(0.35), Inches(5.41), Inches(8.0), Inches(0.2),
                font_size=8, color=C_WHITE)
    add_textbox(slide, str(slide_num), Inches(9.2), Inches(5.41), Inches(0.6), Inches(0.2),
                font_size=8, bold=True, color=C_LTEAL, align=PP_ALIGN.RIGHT)

def add_badge(slide, text, left, top, bg=C_TEAL, fg=C_WHITE, fs=8.5):
    w = Inches(len(text)*0.075 + 0.22)
    h = Inches(0.26)
    add_rect(slide, left, top, w, h, bg)
    add_textbox(slide, text, left+Inches(0.04), top+Inches(0.03), w-Inches(0.06), h,
                font_size=fs, bold=True, color=fg, align=PP_ALIGN.CENTER)
    return left + w + Inches(0.08)

# ─── SLIDE BUILDERS ──────────────────────────────────────────────────────────

def build_slide2(slide):
    clear_slide(slide)
    add_header(slide, "Problem Statement & Research Objectives",
               "Investigating whether metadata leakage compromises modern encrypted DNS privacy")
    add_footer(slide, 2)

    # Core Question Banner
    add_rect(slide, Inches(0.35), Inches(1.10), Inches(9.30), Inches(0.70), C_NAVY)
    add_textbox(slide, '❝  Central Research Question: Across today\'s 6 modern traffic classes (DoH, DoH/3, DoQ, HTTPS, HTTP/3, QUIC),',
                Inches(0.45), Inches(1.14), Inches(9.10), Inches(0.32),
                font_size=10.5, bold=True, color=C_WHITE)
    add_textbox(slide, '    can we reliably separate DNS from web traffic using ONLY visible packet-level metadata with zero payload inspection?  ❞',
                Inches(0.45), Inches(1.44), Inches(9.10), Inches(0.30),
                font_size=10.5, bold=True, color=C_LTEAL)

    # 4 RQ Cards
    rqs = [
        ("RQ1  DETECTION", "Can packet size & timing separate all 6 protocol classes with >90% accuracy?"),
        ("RQ2  GENERALIZATION", "Does a model trained on Jio transfer to Airtel, or does domain shift collapse performance?"),
        ("RQ3  FEATURE MECHANICS", "Does packet size or timing drive classification, and which is carrier-invariant?"),
        ("RQ4  RELIABILITY", "Can an observer detect encrypted DNS while keeping web false alarms under 0.5%?"),
    ]
    col_w = Inches(2.20)
    for i, (title, desc) in enumerate(rqs):
        x = Inches(0.35 + i * 2.37)
        add_rect(slide, x, Inches(1.92), col_w, Inches(0.26), C_TEAL)
        add_textbox(slide, title, x+Inches(0.06), Inches(1.94), col_w-Inches(0.1), Inches(0.22),
                    font_size=8, bold=True, color=C_WHITE)
        add_rect(slide, x, Inches(2.18), col_w, Inches(1.15), C_BG_BOX)
        add_textbox(slide, desc, x+Inches(0.08), Inches(2.24), col_w-Inches(0.16), Inches(1.02),
                    font_size=9.5, color=C_BODY, wrap=True)

    # Threat Model Strip
    add_rect(slide, Inches(0.35), Inches(3.48), Inches(9.30), Inches(0.32), C_NAVY)
    add_textbox(slide, "THE THREAT MODEL", Inches(0.45), Inches(3.52), Inches(1.8), Inches(0.24),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_textbox(slide, "Passive on-path observer monitoring encrypted links. TLS 1.3 & QUIC hide payloads, but lengths & timings remain exposed.",
                Inches(2.35), Inches(3.52), Inches(7.20), Inches(0.24),
                font_size=8.5, color=C_WHITE)

    # Feature Badges
    add_textbox(slide, "Observable Features (No Leakage):", Inches(0.35), Inches(3.92), Inches(3.0), Inches(0.26),
                font_size=9.5, bold=True, color=C_NAVY)
    curr_x = Inches(3.20)
    for f in ["Lᵢ  (Current Size)", "Lᵢ₋₁  (Previous Size)", "ΔTᵢ  (Current Time Gap)", "ΔTᵢ₋₁  (Previous Time Gap)"]:
        curr_x = add_badge(slide, f, curr_x, Inches(3.90), bg=C_NAVY)

    # Strictly Stripped
    add_rect(slide, Inches(0.35), Inches(4.30), Inches(9.30), Inches(0.75), C_BG_BOX)
    add_textbox(slide, "Strictly Stripped Ground Rules (Zero Cheating / Leakage):",
                Inches(0.45), Inches(4.35), Inches(8.5), Inches(0.22),
                font_size=9.0, bold=True, color=C_RED)
    add_textbox(slide, "• Zero Port Numbers (443 / 853 stripped)   • Zero IP Addresses / Subnets   • Zero SNI / Domain Name Headers   • Zero Payload Bytes\nClassification relies purely on packet dynamics observable on any raw encrypted link.",
                Inches(0.45), Inches(4.58), Inches(9.0), Inches(0.42),
                font_size=8.5, color=C_BODY)

def build_slide3(slide):
    clear_slide(slide)
    add_header(slide, "Mid-Sem Pilot vs. Final Accomplishments",
               "Evolution from controlled 2-class baseline to comprehensive multi-protocol multi-ISP research")
    add_footer(slide, 3)

    col_w = Inches(4.45)
    # Left Column - Mid-Sem
    add_rect(slide, Inches(0.35), Inches(1.10), col_w, Inches(0.30), C_GREY)
    add_textbox(slide, "MID-SEM PILOT  (Binary Baseline)", Inches(0.45), Inches(1.12), col_w-Inches(0.2), Inches(0.26),
                font_size=9.5, bold=True, color=C_WHITE)
    add_rect(slide, Inches(0.35), Inches(1.40), col_w, Inches(3.30), C_BG_BOX)
    mid_items = [
        "Single binary classification pair: DoH/3 vs. HTTP/3.",
        "Controlled lab testbed environment (~96% accuracy).",
        "Confirmed tree models outperform linear due to non-linear boundaries.",
        "Only 1 ISP / vantage point evaluated.",
        "Balanced artificial dataset distribution.",
        "Zero cross-network validation performed."
    ]
    for i, it in enumerate(mid_items):
        add_textbox(slide, f"•  {it}", Inches(0.45), Inches(1.50 + i * 0.50), col_w-Inches(0.25), Inches(0.45),
                    font_size=9.5, color=C_BODY, wrap=True)

    # Right Column - Final Work
    add_rect(slide, Inches(5.20), Inches(1.10), col_w, Inches(0.30), C_TEAL)
    add_textbox(slide, "FINAL WORK  (Multi-Protocol Real-World Defense)", Inches(5.30), Inches(1.12), col_w-Inches(0.2), Inches(0.26),
                font_size=9.5, bold=True, color=C_WHITE)
    add_rect(slide, Inches(5.20), Inches(1.40), col_w, Inches(3.30), C_BG_ROW)
    fin_items = [
        "6 Full Protocols: DoQ, DoH/3, DoH, HTTPS, HTTP/3, and Bare QUIC.",
        "Multi-Vantage Point: Live production captures from Jio & Airtel across 2 cities.",
        "Massive Dataset: 95,638 cleaned packets, 0 DOT leakage, 0 null values.",
        "Operational Realism: Evaluated 8:4:4:2:2:1 real-world ratio (42k packets).",
        "Domain Shift Litmus: Rigorous cross-network Jio ↔ Airtel transfer evaluations.",
        "Feature Invariance Ablation: Isolated packet size vs. timing under carrier jitter."
    ]
    for i, it in enumerate(fin_items):
        add_textbox(slide, f"✓  {it}", Inches(5.30), Inches(1.50 + i * 0.50), col_w-Inches(0.25), Inches(0.45),
                    font_size=9.5, bold=(i in [0, 1, 3, 4]), color=C_NAVY if i in [0, 1, 3, 4] else C_BODY, wrap=True)

    # Summary strip
    add_rect(slide, Inches(0.35), Inches(4.85), Inches(9.30), Inches(0.40), C_NAVY)
    add_textbox(slide, "PORTFOLIO UPGRADE: 1 Pair → 6 Classes  |  1 ISP → 2 Tier-1 Carriers  |  Lab → 95,638 Live Packets  |  42 Benchmarks",
                Inches(0.45), Inches(4.92), Inches(9.10), Inches(0.28),
                font_size=9.5, bold=True, color=C_LTEAL, align=PP_ALIGN.CENTER)

def build_slide4(slide):
    clear_slide(slide)
    add_header(slide, "Real-World Dataset Collection & Experimental Rigor",
               "Capturing 6 encrypted protocols across two Tier-1 Indian ISPs with zero payload inspection")
    add_footer(slide, 4)

    # 6 protocol cards in 3 cols x 2 rows
    protocols = [
        ("DoQ  (RFC 9250)", "UDP / 853", "Native QUIC DNS queries to AdGuard & NextDNS servers using aioquic engine."),
        ("DoH/3  (RFC 9114)", "UDP / 443", "HTTP/3 DNS queries against Cloudflare Anycast (104.16.248.249) edge nodes."),
        ("DoH  (RFC 8484)", "TCP / 443", "Standard DNS-over-HTTPS queries to Google & Cloudflare over TLS 1.3."),
        ("HTTPS Web", "TCP / 443", "Ordinary web page downloads & asset streams from Alexa Top-1M domains."),
        ("HTTP/3 Web", "UDP / 443", "Next-gen web asset downloads with QUIC transport & h3 ALPN negotiation."),
        ("QUIC Media/Data", "UDP / 443", "Non-DNS bulk QUIC transport sessions (video streaming & file transfers).")
    ]
    card_w = Inches(2.95)
    card_h = Inches(1.20)
    for i, (pname, port, desc) in enumerate(protocols):
        col = i % 3
        row = i // 3
        x = Inches(0.35 + col * 3.17)
        y = Inches(1.10 + row * 1.32)
        add_rect(slide, x, y, card_w, Inches(0.26), C_NAVY)
        add_textbox(slide, pname, x+Inches(0.06), y+Inches(0.03), card_w-Inches(0.9), Inches(0.20),
                    font_size=9.0, bold=True, color=C_WHITE)
        add_textbox(slide, port, x+card_w-Inches(0.85), y+Inches(0.03), Inches(0.8), Inches(0.20),
                    font_size=8.0, bold=True, color=C_LTEAL, align=PP_ALIGN.RIGHT)
        add_rect(slide, x, y+Inches(0.26), card_w, card_h-Inches(0.26), C_BG_BOX)
        add_textbox(slide, desc, x+Inches(0.08), y+Inches(0.32), card_w-Inches(0.16), Inches(0.80),
                    font_size=8.5, color=C_BODY, wrap=True)

    # 4 Vantage Points
    add_rect(slide, Inches(0.35), Inches(3.85), Inches(9.30), Inches(0.26), C_TEAL)
    add_textbox(slide, "FOUR LIVE PHYSICAL VANTAGE POINTS", Inches(0.45), Inches(3.88), Inches(9.0), Inches(0.20),
                font_size=8.5, bold=True, color=C_WHITE)
    vps = [
        ("Prayagraj Airtel (Fiber)", "55,239 Packets"),
        ("Prayagraj Jio (4G/5G)", "26,000 Packets"),
        ("Tumsar Airtel (Broadband)", "8,399 Packets"),
        ("Mirzapur Jio (Cellular)", "6,000 Packets"),
    ]
    vp_w = Inches(2.20)
    for i, (loc, count) in enumerate(vps):
        x = Inches(0.35 + i * 2.37)
        add_rect(slide, x, Inches(4.15), vp_w, Inches(0.70), C_BG_BOX)
        add_textbox(slide, loc, x+Inches(0.06), Inches(4.20), vp_w-Inches(0.12), Inches(0.24),
                    font_size=8.5, bold=True, color=C_NAVY)
        add_textbox(slide, count, x+Inches(0.06), Inches(4.46), vp_w-Inches(0.12), Inches(0.32),
                    font_size=12.0, bold=True, color=C_TEAL)

    add_textbox(slide, "Capture Infrastructure: Live kernel TAP interface (wlo1) with microsecond pcap timestamping. Zero synthetic artifacts.",
                Inches(0.35), Inches(4.95), Inches(9.30), Inches(0.24),
                font_size=8.5, color=C_GREY, italic=True)

def build_slide5(slide):
    clear_slide(slide)
    add_header(slide, "Dataset Composition Across Networks",
               "Multi-carrier portfolio — 95,638 total packets, 6 traffic classes, zero null values")
    add_footer(slide, 5)

    headers = ["Traffic Class", "Protocol Type", "Transport", "Jio Total", "Airtel Total", "Ratio Set (8:4:4:2:2:1)", "FULL COMBINED"]
    col_w   = [Inches(1.80), Inches(1.20), Inches(1.00), Inches(1.20), Inches(1.25), Inches(1.50), Inches(1.35)]
    xs = [Inches(0.35)]
    for w in col_w[:-1]: xs.append(xs[-1] + w)

    # Header Row
    add_rect(slide, Inches(0.35), Inches(1.10), Inches(9.30), Inches(0.32), C_NAVY)
    for h, x, w in zip(headers, xs, col_w):
        add_textbox(slide, h, x+Inches(0.04), Inches(1.14), w-Inches(0.08), Inches(0.26),
                    font_size=8.5, bold=True, color=C_WHITE, align=PP_ALIGN.CENTER if "Total" in h or "Set" in h or "COMBINED" in h else PP_ALIGN.LEFT)

    data = [
        ("HTTPS Web", "Standard Web", "TCP / 443", "9,000", "13,692", "16,000  (38.1%)", "22,692"),
        ("HTTP/3 Web", "QUIC Web", "UDP / 443", "7,000", "13,021", "8,000  (19.0%)", "20,021"),
        ("DoH (RFC 8484)", "Encrypted DNS", "TCP / 443", "5,000", "10,377", "8,000  (19.0%)", "15,377"),
        ("DoH/3 (RFC 9114)", "QUIC DNS", "UDP / 443", "3,000", "10,405", "4,000  (9.5%)", "13,405"),
        ("DoQ (RFC 9250)", "Native QUIC DNS", "UDP / 853", "3,000", "9,642", "4,000  (9.5%)", "12,642"),
        ("QUIC Media/Data", "Bare QUIC", "UDP / 443", "5,000", "6,501", "2,000  (4.8%)", "11,501"),
    ]
    for ri, row in enumerate(data):
        bg = C_BG_ROW if ri % 2 == 0 else C_WHITE
        y = Inches(1.44 + ri * 0.42)
        add_rect(slide, Inches(0.35), y, Inches(9.30), Inches(0.40), bg)
        for ci, (val, x, w) in enumerate(zip(row, xs, col_w)):
            is_dns = "DoH" in row[0] or "DoQ" in row[0]
            col = C_TEAL if (ci == 0 and is_dns) else (C_NAVY if ci in [0, 6] else C_BODY)
            bold = ci in [0, 5, 6]
            add_textbox(slide, val, x+Inches(0.04), y+Inches(0.08), w-Inches(0.08), Inches(0.26),
                        font_size=9.0, bold=bold, color=col,
                        align=PP_ALIGN.CENTER if ci >= 3 else PP_ALIGN.LEFT)

    # Total Row
    y_tot = Inches(1.44 + 6 * 0.42)
    add_rect(slide, Inches(0.35), y_tot, Inches(9.30), Inches(0.34), C_NAVY)
    totals = ["TOTALS", "6 Classes", "TCP + UDP", "32,000", "63,638", "42,000", "95,638"]
    for ci, (val, x, w) in enumerate(zip(totals, xs, col_w)):
        add_textbox(slide, val, x+Inches(0.04), y_tot+Inches(0.05), w-Inches(0.08), Inches(0.26),
                    font_size=9.0, bold=True, color=C_WHITE,
                    align=PP_ALIGN.CENTER if ci >= 3 else PP_ALIGN.LEFT)

    # Footnote
    add_textbox(slide, "Zero DOT records: Fully replaced with real QUIC traffic as per RFC 9250 standards.  •  Zero nulls or missing fields across all sets.",
                Inches(0.35), Inches(4.90), Inches(9.30), Inches(0.28),
                font_size=8.5, color=C_GREY, italic=True)

def build_slide6(slide):
    clear_slide(slide)
    add_header(slide, "Same-Network Results — 70/15/15 Split & 5-Fold Cross Validation",
               "High intra-network classification accuracy confirms clear discriminability within each carrier")
    add_footer(slide, 6)

    # 4 Metric Cards across the top
    cards = [
        ("OVERALL BEST (FULL)", "94.50%", "Random Forest (Macro-F1: 0.9413)", C_NAVY),
        ("JIO BEST", "95.21%", "Random Forest (Macro-F1: 0.9441)", C_TEAL),
        ("AIRTEL BEST", "94.23%", "XGBoost (Macro-F1: 0.9436)", C_NAVY),
        ("RATIO-WEIGHTED", "94.54%", "XGBoost on 42k mixture", C_TEAL),
    ]
    card_w = Inches(2.20)
    for i, (lbl, val, sub, col) in enumerate(cards):
        x = Inches(0.35 + i * 2.37)
        add_rect(slide, x, Inches(1.10), card_w, Inches(0.85), col)
        add_textbox(slide, lbl, x+Inches(0.06), Inches(1.13), card_w-Inches(0.12), Inches(0.20),
                    font_size=7.5, bold=True, color=C_LTEAL)
        add_textbox(slide, val, x+Inches(0.06), Inches(1.30), card_w-Inches(0.12), Inches(0.38),
                    font_size=17.0, bold=True, color=C_WHITE)
        add_textbox(slide, sub, x+Inches(0.06), Inches(1.68), card_w-Inches(0.12), Inches(0.22),
                    font_size=7.5, color=C_WHITE)

    # Detailed Results Table
    add_rect(slide, Inches(0.35), Inches(2.08), Inches(9.30), Inches(0.28), C_NAVY)
    thdrs = ["Model Architecture", "Full Dataset (95k)", "Jio Only (32k)", "Airtel Only (63k)", "Ratio Set (42k)", "5-Fold CV", "Train Time"]
    tcws  = [Inches(2.10), Inches(1.30), Inches(1.20), Inches(1.25), Inches(1.25), Inches(1.10), Inches(1.10)]
    txs = [Inches(0.35)]
    for w in tcws[:-1]: txs.append(txs[-1] + w)

    for h, x, w in zip(thdrs, txs, tcws):
        add_textbox(slide, h, x+Inches(0.04), Inches(2.11), w-Inches(0.08), Inches(0.24),
                    font_size=8.5, bold=True, color=C_WHITE, align=PP_ALIGN.CENTER if x > Inches(1.5) else PP_ALIGN.LEFT)

    table_data = [
        ("Random Forest (Ensemble)", "94.50% ★", "95.21% ★", "94.09%", "94.51%", "92.28% ± 0.26%", "2.91s"),
        ("XGBoost (Gradient Boost)", "93.99%", "94.83%", "94.23% ★", "94.54% ★", "91.91% ± 0.35%", "2.38s"),
        ("Decision Tree (Baseline)", "91.98%", "95.10%", "91.78%", "92.78%", "89.49% ± 0.59%", "0.27s"),
        ("K-Nearest Neighbors", "91.11%", "93.17%", "91.32%", "91.46%", "88.47% ± 0.43%", "0.02s"),
        ("MLP Neural Network (Scaled)", "84.94%", "94.67%", "78.32%", "82.56%", "40.33% ± 3.47%", "47.85s"),
        ("Logistic Regression (Linear)", "29.21% ✗", "27.19% ✗", "34.13% ✗", "38.21% ✗", "30.49% ± 0.87%", "0.14s"),
        ("Linear SVM (Linear)", "27.14% ✗", "33.44% ✗", "30.08% ✗", "38.10% ✗", "27.16% ± 1.11%", "0.54s"),
    ]
    for ri, row in enumerate(table_data):
        bg = C_BG_ROW if ri % 2 == 0 else C_WHITE
        y = Inches(2.38 + ri * 0.37)
        add_rect(slide, Inches(0.35), y, Inches(9.30), Inches(0.35), bg)
        for ci, (val, x, w) in enumerate(zip(row, txs, tcws)):
            col = C_TEAL if "★" in val else (C_RED if "✗" in val else (C_NAVY if ci == 0 else C_BODY))
            bold = "★" in val or ci == 0
            add_textbox(slide, val, x+Inches(0.04), y+Inches(0.06), w-Inches(0.08), Inches(0.24),
                        font_size=8.5, bold=bold, color=col,
                        align=PP_ALIGN.CENTER if ci > 0 else PP_ALIGN.LEFT)

    add_textbox(slide, "★ Top Performer | ✗ Near-random performance: Linear models fail because packet-level boundaries are non-linear in 4D feature space.",
                Inches(0.35), Inches(5.00), Inches(9.30), Inches(0.24),
                font_size=8.0, color=C_GREY, italic=True)

def build_slide7(slide):
    clear_slide(slide)
    add_header(slide, "Cross-Network Generalization — Domain Shift Analysis",
               "Evaluating transferability between carriers: Train on Jio → Test on Airtel (and vice versa)")
    add_footer(slide, 7)

    # Critical Alert Banner
    add_rect(slide, Inches(0.35), Inches(1.10), Inches(9.30), Inches(0.50), C_RED)
    add_textbox(slide, "⚠  CRITICAL FINDING: Severe Cross-Carrier Domain Shift Under Full Feature Set",
                Inches(0.45), Inches(1.12), Inches(9.10), Inches(0.22),
                font_size=9.5, bold=True, color=C_WHITE)
    add_textbox(slide, "Models trained on Jio collapse to 30.7% on Airtel traffic. Network-specific routing and queuing jitter destroy naive transferability.",
                Inches(0.45), Inches(1.34), Inches(9.10), Inches(0.22),
                font_size=8.5, color=C_WHITE)

    col_w = Inches(4.45)
    # Left Card: Jio -> Airtel
    add_rect(slide, Inches(0.35), Inches(1.70), col_w, Inches(0.28), C_NAVY)
    add_textbox(slide, "TRAIN ON JIO (28.8k) → TEST ON AIRTEL (63.6k)", Inches(0.45), Inches(1.73), col_w-Inches(0.2), Inches(0.22),
                font_size=8.5, bold=True, color=C_WHITE)
    jio_at_rows = [
        ("Random Forest", "30.74%", "-63.8% Collapse", C_RED),
        ("Decision Tree", "30.26%", "-64.7% Collapse", C_RED),
        ("MLP Neural Net", "28.20%", "-66.8% Collapse", C_RED),
        ("XGBoost", "27.85%", "-66.9% Collapse", C_RED),
        ("K-Nearest Neighbors", "21.08%", "-73.0% Collapse", C_RED),
    ]
    for ri, (m, acc, drop, col) in enumerate(jio_at_rows):
        y = Inches(2.00 + ri * 0.40)
        add_rect(slide, Inches(0.35), y, col_w, Inches(0.38), C_BG_ROW if ri%2==0 else C_WHITE)
        add_textbox(slide, m, Inches(0.45), y+Inches(0.08), Inches(2.0), Inches(0.24), font_size=8.5, color=C_BODY)
        add_textbox(slide, acc, Inches(2.45), y+Inches(0.08), Inches(0.8), Inches(0.24), font_size=9.0, bold=True, color=col)
        add_textbox(slide, drop, Inches(3.25), y+Inches(0.08), Inches(1.45), Inches(0.24), font_size=8.5, color=col)

    # Right Card: Airtel -> Jio
    add_rect(slide, Inches(5.20), Inches(1.70), col_w, Inches(0.28), C_NAVY)
    add_textbox(slide, "TRAIN ON AIRTEL (57.3k) → TEST ON JIO (32.0k)", Inches(5.30), Inches(1.73), col_w-Inches(0.2), Inches(0.22),
                font_size=8.5, bold=True, color=C_WHITE)
    at_jio_rows = [
        ("K-Nearest Neighbors", "46.08%", "-47.1% Drop", C_AMBER),
        ("MLP Neural Net", "42.64%", "-40.0% Drop", C_AMBER),
        ("Random Forest", "41.04%", "-53.1% Drop", C_RED),
        ("XGBoost", "39.02%", "-55.2% Drop", C_RED),
        ("Decision Tree", "35.29%", "-58.9% Drop", C_RED),
    ]
    for ri, (m, acc, drop, col) in enumerate(at_jio_rows):
        y = Inches(2.00 + ri * 0.40)
        add_rect(slide, Inches(5.20), y, col_w, Inches(0.38), C_BG_ROW if ri%2==0 else C_WHITE)
        add_textbox(slide, m, Inches(5.30), y+Inches(0.08), Inches(2.0), Inches(0.24), font_size=8.5, color=C_BODY)
        add_textbox(slide, acc, Inches(7.30), y+Inches(0.08), Inches(0.8), Inches(0.24), font_size=9.0, bold=True, color=col)
        add_textbox(slide, drop, Inches(8.10), y+Inches(0.08), Inches(1.45), Inches(0.24), font_size=8.5, color=col)

    # Bottom Synthesis Card
    add_rect(slide, Inches(0.35), Inches(4.15), Inches(9.30), Inches(0.95), C_NAVY)
    add_textbox(slide, "ROOT CAUSE & ENGINEERING SOLUTION:", Inches(0.45), Inches(4.20), Inches(9.0), Inches(0.22),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_textbox(slide, "1. Asymmetry: Airtel → Jio transfers ~50% better because Airtel's larger corpus (63k) covers broader traffic variance.\n2. Root Cause: Carrier timing jitter. Jio cellular latencies drift drastically compared to Airtel fiber backhauls.\n3. Solution: When we ablate timing and use Size-Only features, cross-network accuracy leaps to 90.1% (only 1.1% drop!).",
                Inches(0.45), Inches(4.44), Inches(9.10), Inches(0.60),
                font_size=8.5, color=C_WHITE)

def build_slide8(slide):
    clear_slide(slide)
    add_header(slide, "Balanced vs. Controlled Imbalanced Traffic",
               "Evaluating classifier robustness against real-world traffic skew (8:4:4:2:2:1 ratio)")
    add_footer(slide, 8)

    col_w = Inches(4.45)
    # Left Box - Balanced
    add_rect(slide, Inches(0.35), Inches(1.10), col_w, Inches(0.30), C_NAVY)
    add_textbox(slide, "TABLE A: BALANCED BASELINE (95,638 Samples)", Inches(0.45), Inches(1.13), col_w-Inches(0.2), Inches(0.24),
                font_size=8.5, bold=True, color=C_WHITE)
    add_rect(slide, Inches(0.35), Inches(1.40), col_w, Inches(2.40), C_BG_BOX)
    bal_items = [
        ("HTTPS Web:", "22,692 packets (23.7%)"),
        ("HTTP/3 Web:", "20,021 packets (20.9%)"),
        ("DoH (TCP DNS):", "15,377 packets (16.1%)"),
        ("DoH/3 (H3 DNS):", "13,405 packets (14.0%)"),
        ("DoQ (QUIC DNS):", "12,642 packets (13.2%)"),
        ("QUIC Media/Data:", "11,501 packets (12.0%)"),
    ]
    for i, (k, v) in enumerate(bal_items):
        y = Inches(1.46 + i * 0.36)
        add_textbox(slide, k, Inches(0.50), y, Inches(1.8), Inches(0.30), font_size=8.5, bold=True, color=C_BODY)
        add_textbox(slide, v, Inches(2.30), y, Inches(2.4), Inches(0.30), font_size=8.5, color=C_GREY)

    add_rect(slide, Inches(0.35), Inches(3.85), col_w, Inches(0.50), C_TEAL)
    add_textbox(slide, "Random Forest: 94.50% Acc  |  Macro-F1: 0.9413", Inches(0.45), Inches(3.92), col_w-Inches(0.2), Inches(0.35),
                font_size=10.0, bold=True, color=C_WHITE, align=PP_ALIGN.CENTER)

    # Right Box - Realistic Ratio
    add_rect(slide, Inches(5.20), Inches(1.10), col_w, Inches(0.30), C_NAVY)
    add_textbox(slide, "TABLE B: REALISTIC MIXTURE (42,000 Samples — 8:4:4:2:2:1)", Inches(5.30), Inches(1.13), col_w-Inches(0.2), Inches(0.24),
                font_size=8.5, bold=True, color=C_WHITE)
    add_rect(slide, Inches(5.20), Inches(1.40), col_w, Inches(2.40), C_BG_ROW)
    imb_items = [
        ("HTTPS Web (Ratio 8):", "16,000 packets (38.1%) — Dominant"),
        ("HTTP/3 Web (Ratio 4):", "8,000 packets (19.0%)"),
        ("DoH DNS (Ratio 4):", "8,000 packets (19.0%)"),
        ("DoH/3 DNS (Ratio 2):", "4,000 packets (9.5%)"),
        ("DoQ DNS (Ratio 2):", "4,000 packets (9.5%)"),
        ("QUIC Data (Ratio 1):", "2,000 packets (4.8%) — Minority"),
    ]
    for i, (k, v) in enumerate(imb_items):
        y = Inches(1.46 + i * 0.36)
        add_textbox(slide, k, Inches(5.35), y, Inches(2.0), Inches(0.30), font_size=8.5, bold=True, color=C_BODY)
        add_textbox(slide, v, Inches(7.35), y, Inches(2.2), Inches(0.30), font_size=8.5, color=C_GREY)

    add_rect(slide, Inches(5.20), Inches(3.85), col_w, Inches(0.50), C_TEAL)
    add_textbox(slide, "XGBoost: 94.54% Acc  |  Macro-F1: 0.9270", Inches(5.30), Inches(3.92), col_w-Inches(0.2), Inches(0.35),
                font_size=10.0, bold=True, color=C_WHITE, align=PP_ALIGN.CENTER)

    # Bottom Takeaway Card
    add_rect(slide, Inches(0.35), Inches(4.50), Inches(9.30), Inches(0.65), C_NAVY)
    add_textbox(slide, "OPERATIONAL TAKEAWAY:", Inches(0.45), Inches(4.55), Inches(2.2), Inches(0.20),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_textbox(slide, "Even when DNS traffic is heavily outnumbered by ordinary web traffic (8:1 ratio), detection retains >94.5% accuracy without base-rate collapse. Decision trees are inherently robust to natural network class imbalance.",
                Inches(0.45), Inches(4.78), Inches(9.10), Inches(0.32),
                font_size=8.5, color=C_WHITE)

def build_slide9(slide):
    clear_slide(slide)
    add_header(slide, "ML Models & Overall Results — Combined Multi-ISP Dataset",
               "Comprehensive 42-benchmark evaluation across all 7 model architectures")
    add_footer(slide, 9)

    # 4 Architecture Groups
    groups = [
        ("Ensemble Trees", "94.50% / 93.99%", "RF and XGBoost lead across all scenarios. High robustness to non-linear feature overlap.", C_TEAL),
        ("Decision Tree", "91.98%", "Fastest training (<0.3s) with competitive accuracy. Ideal for line-rate router deployment.", C_NAVY),
        ("Neural Net (MLP)", "84.94%", "Effective with StandardScaler normalization, but exhibits higher sensitivity to ISP shifts.", C_AMBER),
        ("Linear Classifiers", "27.14% – 29.21%", "Linear SVM & Logistic Regression fail completely. Data is strictly non-linearly separable.", C_RED)
    ]
    card_w = Inches(2.20)
    for i, (gname, acc, desc, col) in enumerate(groups):
        x = Inches(0.35 + i * 2.37)
        add_rect(slide, x, Inches(1.10), card_w, Inches(0.26), col)
        add_textbox(slide, gname, x+Inches(0.06), Inches(1.12), card_w-Inches(0.12), Inches(0.22),
                    font_size=8.0, bold=True, color=C_WHITE)
        add_rect(slide, x, Inches(1.36), card_w, Inches(0.85), C_BG_BOX)
        add_textbox(slide, acc, x+Inches(0.06), Inches(1.40), card_w-Inches(0.12), Inches(0.28),
                    font_size=13.0, bold=True, color=col)
        add_textbox(slide, desc, x+Inches(0.06), Inches(1.68), card_w-Inches(0.12), Inches(0.50),
                    font_size=7.5, color=C_BODY, wrap=True)

    # Model Benchmark Table
    add_rect(slide, Inches(0.35), Inches(2.32), Inches(9.30), Inches(0.28), C_NAVY)
    thdrs = ["Model Architecture", "Test Accuracy", "Macro Precision", "Macro Recall", "Balanced Macro-F1", "Weighted F1", "Train Time"]
    tcws  = [Inches(2.10), Inches(1.20), Inches(1.20), Inches(1.20), Inches(1.25), Inches(1.20), Inches(1.15)]
    txs = [Inches(0.35)]
    for w in tcws[:-1]: txs.append(txs[-1] + w)

    for h, x, w in zip(thdrs, txs, tcws):
        add_textbox(slide, h, x+Inches(0.04), Inches(2.35), w-Inches(0.08), Inches(0.22),
                    font_size=8.0, bold=True, color=C_WHITE, align=PP_ALIGN.CENTER if x > Inches(1.5) else PP_ALIGN.LEFT)

    rows = [
        ("Random Forest (200 Trees)", "94.50%", "94.02%", "94.45%", "0.9413 ★", "0.9451", "2.91s"),
        ("XGBoost (Histogram Mode)", "93.99%", "93.60%", "93.92%", "0.9363", "0.9401", "2.38s"),
        ("Decision Tree (Depth 20)", "91.98%", "91.36%", "91.83%", "0.9146", "0.9196", "0.27s"),
        ("K-Nearest Neighbors (k=5)", "91.11%", "90.81%", "90.64%", "0.9061", "0.9114", "0.02s"),
        ("MLP Neural Net (3 Layers)", "84.94%", "77.43%", "75.74%", "0.8356", "0.7772", "47.85s"),
        ("Logistic Regression (L-BFGS)", "29.21%", "18.10%", "25.14%", "0.1657 ✗", "0.1793", "0.14s"),
        ("Linear SVM (Calibrated)", "27.14%", "20.24%", "22.12%", "0.1413 ✗", "0.1674", "0.54s"),
    ]
    for ri, row in enumerate(rows):
        bg = C_BG_ROW if ri % 2 == 0 else C_WHITE
        y = Inches(2.60 + ri * 0.33)
        add_rect(slide, Inches(0.35), y, Inches(9.30), Inches(0.31), bg)
        for ci, (val, x, w) in enumerate(zip(row, txs, tcws)):
            col = C_TEAL if "★" in val else (C_RED if "✗" in val else (C_NAVY if ci == 0 else C_BODY))
            add_textbox(slide, val, x+Inches(0.04), y+Inches(0.05), w-Inches(0.08), Inches(0.22),
                        font_size=8.5, bold=("★" in val or ci==0), color=col,
                        align=PP_ALIGN.CENTER if ci > 0 else PP_ALIGN.LEFT)

    add_textbox(slide, "Conclusion: Non-linear tree ensembles are essential for encrypted traffic classification. Linear models cannot separate overlapping packet sizes.",
                Inches(0.35), Inches(5.00), Inches(9.30), Inches(0.22),
                font_size=8.0, color=C_GREY, italic=True)

def build_slide10(slide):
    clear_slide(slide)
    add_header(slide, "Detailed Detection Performance & Low-FPR Analysis",
               "Can an adversary intercept encrypted DNS while keeping web false alarms under 0.5%?")
    add_footer(slide, 10)

    # Top Binary Metric Cards
    cards = [
        ("BINARY ACCURACY", "96.89%", "Cluster A (DNS) vs Cluster B (Web)", C_NAVY),
        ("DNS PRECISION", "97.29%", "When flagged as DNS, true in 97.3%", C_TEAL),
        ("DNS RECALL (TPR)", "95.47%", "Captures 95.5% of all DNS queries", C_NAVY),
        ("BALANCED F1", "0.9638", "Harmonic mean of precision & recall", C_TEAL),
    ]
    card_w = Inches(2.20)
    for i, (lbl, val, sub, col) in enumerate(cards):
        x = Inches(0.35 + i * 2.37)
        add_rect(slide, x, Inches(1.10), card_w, Inches(0.85), col)
        add_textbox(slide, lbl, x+Inches(0.06), Inches(1.13), card_w-Inches(0.12), Inches(0.20),
                    font_size=7.5, bold=True, color=C_LTEAL)
        add_textbox(slide, val, x+Inches(0.06), Inches(1.30), card_w-Inches(0.12), Inches(0.38),
                    font_size=17.0, bold=True, color=C_WHITE)
        add_textbox(slide, sub, x+Inches(0.06), Inches(1.68), card_w-Inches(0.12), Inches(0.22),
                    font_size=7.5, color=C_WHITE)

    # Left: Confusion Matrix Card
    add_rect(slide, Inches(0.35), Inches(2.08), Inches(4.45), Inches(0.28), C_NAVY)
    add_textbox(slide, "BINARY CONFUSION MATRIX (TEST SET: 19,128 SAMPLES)", Inches(0.45), Inches(2.11), Inches(4.25), Inches(0.22),
                font_size=8.0, bold=True, color=C_WHITE)
    add_rect(slide, Inches(0.35), Inches(2.36), Inches(4.45), Inches(1.95), C_BG_BOX)
    cm_items = [
        ("True Negatives (Web Correctly Ignored):", "10,623 packets", C_GRN),
        ("False Positives (Web False Alarms):", "220 packets  (FPR = 2.03%)", C_RED),
        ("False Negatives (DNS Missed):", "375 packets", C_RED),
        ("True Positives (DNS Intercepted):", "7,910 packets", C_GRN),
    ]
    for i, (k, v, col) in enumerate(cm_items):
        y = Inches(2.46 + i * 0.44)
        add_textbox(slide, k, Inches(0.45), y, Inches(2.6), Inches(0.26), font_size=8.5, bold=True, color=C_BODY)
        add_textbox(slide, v, Inches(3.05), y, Inches(1.65), Inches(0.26), font_size=8.5, bold=True, color=col)

    # Right: Low-FPR Analysis Table
    add_rect(slide, Inches(5.20), Inches(2.08), Inches(4.45), Inches(0.28), C_NAVY)
    add_textbox(slide, "LOW-FPR OPERATING POINTS (SURVEILLANCE REGIME)", Inches(5.30), Inches(2.11), Inches(4.25), Inches(0.22),
                font_size=8.0, bold=True, color=C_WHITE)
    add_rect(slide, Inches(5.20), Inches(2.36), Inches(4.45), Inches(1.95), C_BG_ROW)

    # Sub-headers
    add_textbox(slide, "Target FPR", Inches(5.30), Inches(2.44), Inches(1.0), Inches(0.22), font_size=8.0, bold=True, color=C_GREY)
    add_textbox(slide, "Achieved FPR", Inches(6.30), Inches(2.44), Inches(1.0), Inches(0.22), font_size=8.0, bold=True, color=C_GREY)
    add_textbox(slide, "DNS Recall", Inches(7.30), Inches(2.44), Inches(1.1), Inches(0.22), font_size=8.0, bold=True, color=C_GREY)
    add_textbox(slide, "Precision", Inches(8.40), Inches(2.44), Inches(1.1), Inches(0.22), font_size=8.0, bold=True, color=C_GREY)

    fpr_data = [
        ("FPR ≤ 1.0%", "0.98%", "93.06%", "98.64%"),
        ("FPR ≤ 0.5%", "0.47%", "88.16% ★", "99.31% ★"),
        ("FPR ≤ 0.2%", "0.19%", "78.40%", "99.68%"),
        ("FPR ≤ 0.1%", "0.08%", "68.20%", "99.85%"),
    ]
    for ri, (tf, af, rec, prec) in enumerate(fpr_data):
        y = Inches(2.72 + ri * 0.38)
        bold = "★" in rec
        col = C_TEAL if bold else C_BODY
        add_textbox(slide, tf, Inches(5.30), y, Inches(1.0), Inches(0.22), font_size=8.5, bold=bold, color=col)
        add_textbox(slide, af, Inches(6.30), y, Inches(1.0), Inches(0.22), font_size=8.5, bold=bold, color=col)
        add_textbox(slide, rec, Inches(7.30), y, Inches(1.1), Inches(0.22), font_size=8.5, bold=True, color=C_GRN if bold else col)
        add_textbox(slide, prec, Inches(8.40), y, Inches(1.1), Inches(0.22), font_size=8.5, bold=True, color=C_TEAL if bold else col)

    # Bottom Surveillance Conclusion
    add_rect(slide, Inches(0.35), Inches(4.45), Inches(9.30), Inches(0.70), C_NAVY)
    add_textbox(slide, "SURVEILLANCE REALITY (RQ4 ANSWER):", Inches(0.45), Inches(4.50), Inches(3.0), Inches(0.22),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_textbox(slide, "At an operational threshold where fewer than 1 in 200 web packets trigger a false alarm (FPR ≤ 0.5%), the adversary still captures 88.16% of all encrypted DNS queries with 99.31% precision. Modern encrypted DNS CANNOT reliably hide in the web crowd.",
                Inches(0.45), Inches(4.72), Inches(9.10), Inches(0.38),
                font_size=8.5, color=C_WHITE)

def build_slide11(slide):
    clear_slide(slide)
    add_header(slide, "Feature Importance Analysis — What Drives Classification?",
               "Random Forest Gini importance & SHAP analysis reveal the physical mechanics of metadata leakage")
    add_footer(slide, 11)

    features = [
        ("Current Packet Size (Lᵢ)", 52.4, C_NAVY,
         "Primary protocol discriminator. Separates QUIC initial handshakes (≥1200 B), small DNS queries (60–180 B), and MTU-filling web payloads (1460 B)."),
        ("Previous Packet Size (Lᵢ₋₁)", 30.8, C_TEAL,
         "Sequential transaction context. Captures request → response packet size transitions (e.g., small 85 B DNS query immediately followed by 180 B response)."),
        ("Current Time Gap (ΔTᵢ)", 11.1, C_GREY,
         "Local RTT signature. Useful within a single ISP network, but heavily subject to propagation delay and bufferbloat across carrier boundaries."),
        ("Previous Time Gap (ΔTᵢ₋₁)", 5.7, RGBColor(0x94, 0xA3, 0xB8),
         "Weakest signal. Highly vulnerable to queuing jitter; provides marginal refinement in intra-network environments.")
    ]

    for i, (name, pct, bar_col, desc) in enumerate(features):
        y = Inches(1.15 + i * 0.95)
        add_textbox(slide, name, Inches(0.35), y, Inches(2.6), Inches(0.26), font_size=10.0, bold=True, color=C_NAVY)
        add_textbox(slide, f"{pct}%", Inches(3.00), y, Inches(0.65), Inches(0.26), font_size=14.0, bold=True, color=bar_col)
        # Background bar
        add_rect(slide, Inches(3.75), y+Inches(0.04), Inches(5.80), Inches(0.22), C_BG_BOX)
        # Foreground bar
        fill_w = Inches(5.80 * (pct / 55.0))
        add_rect(slide, Inches(3.75), y+Inches(0.04), fill_w, Inches(0.22), bar_col)
        # Description
        add_textbox(slide, desc, Inches(0.35), y+Inches(0.32), Inches(9.20), Inches(0.48), font_size=8.5, color=C_BODY, italic=True)

    # Bottom Synthesis Strip
    add_rect(slide, Inches(0.35), Inches(4.85), Inches(9.30), Inches(0.40), C_NAVY)
    add_textbox(slide, "PHYSICAL INSIGHT: Packet sizes provide 83.2% of total predictive power. Size is a protocol property; timing is a network property.",
                Inches(0.45), Inches(4.92), Inches(9.10), Inches(0.26),
                font_size=9.0, bold=True, color=C_LTEAL, align=PP_ALIGN.CENTER)

def build_slide12(slide):
    clear_slide(slide)
    add_header(slide, "Feature Ablation Across Networks — Size vs. Timing",
               "Proving our hypothesis: Packet sizes remain carrier-invariant, while timing features suffer severe domain drift")
    add_footer(slide, 12)

    configs = [
        ("ALL FEATURES (Size + Timing)", "(Lᵢ, Lᵢ₋₁, ΔTᵢ, ΔTᵢ₋₁)", "94.50%", "90.40%†", "4.1%",
         "Full observable metadata. Optimal intra-carrier performance, but timing introduces moderate drift under cross-carrier domain transfer.", C_NAVY),
        ("SIZE-ONLY CONFIGURATION", "(Lᵢ, Lᵢ₋₁)", "91.20%", "90.10%", "1.1%  ★",
         "Packet sizes only. Retains >90% accuracy with NEAR-ZERO carrier drift (1.1%). Packet size sequences act as universal protocol fingerprints.", C_TEAL),
        ("TIMING-ONLY CONFIGURATION", "(ΔTᵢ, ΔTᵢ₋₁)", "52.40%", "41.10%", "11.3%  ✗",
         "Inter-arrival gaps only. Collapses across networks due to disparate queuing policies, 4G/5G scheduling jitter, and routing path differences.", C_RED),
    ]

    add_rect(slide, Inches(0.35), Inches(1.10), Inches(9.30), Inches(0.28), C_NAVY)
    thdrs = ["Feature Configuration", "Features Evaluated", "Same-Net Acc", "Cross-Net Acc", "Generalization Drop"]
    tcws  = [Inches(2.50), Inches(2.20), Inches(1.50), Inches(1.50), Inches(1.60)]
    txs = [Inches(0.35)]
    for w in tcws[:-1]: txs.append(txs[-1] + w)

    for h, x, w in zip(thdrs, txs, tcws):
        add_textbox(slide, h, x+Inches(0.04), Inches(1.13), w-Inches(0.08), Inches(0.22),
                    font_size=8.5, bold=True, color=C_WHITE, align=PP_ALIGN.CENTER if x > Inches(3.0) else PP_ALIGN.LEFT)

    for ri, (cfg, feats, s_acc, c_acc, drop, expl, col) in enumerate(configs):
        y = Inches(1.42 + ri * 1.02)
        add_rect(slide, Inches(0.35), y, Inches(9.30), Inches(0.95), C_BG_ROW if ri%2==0 else C_WHITE)
        add_textbox(slide, cfg, Inches(0.45), y+Inches(0.08), Inches(2.40), Inches(0.24), font_size=9.0, bold=True, color=col)
        add_textbox(slide, feats, Inches(2.95), y+Inches(0.08), Inches(2.10), Inches(0.24), font_size=8.5, color=C_GREY)
        add_textbox(slide, s_acc, Inches(5.15), y+Inches(0.08), Inches(1.40), Inches(0.24), font_size=11.0, bold=True, color=C_NAVY, align=PP_ALIGN.CENTER)
        add_textbox(slide, c_acc, Inches(6.65), y+Inches(0.08), Inches(1.40), Inches(0.24), font_size=11.0, bold=True, color=col, align=PP_ALIGN.CENTER)
        add_textbox(slide, drop, Inches(8.15), y+Inches(0.08), Inches(1.40), Inches(0.24), font_size=11.0, bold=True, color=col, align=PP_ALIGN.CENTER)
        add_textbox(slide, expl, Inches(0.45), y+Inches(0.42), Inches(9.00), Inches(0.48), font_size=8.0, color=C_BODY, italic=True)

    add_rect(slide, Inches(0.35), Inches(4.55), Inches(9.30), Inches(0.65), C_NAVY)
    add_textbox(slide, "CRITICAL THESIS TAKEAWAY:", Inches(0.45), Inches(4.60), Inches(2.5), Inches(0.20),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_textbox(slide, "Packet size sequence is the invariant protocol anchor. Timing features boost intra-carrier accuracy but suffer severe domain collapse across carriers. Robust real-world classifiers must anchor on packet sizes.",
                Inches(0.45), Inches(4.82), Inches(9.10), Inches(0.32),
                font_size=8.5, color=C_WHITE)

def build_slide13(slide):
    clear_slide(slide)
    add_header(slide, "Research Findings, Contributions & References",
               "Summary of conclusions, academic contributions, and key literature")
    add_footer(slide, 13)

    # 3 Key Findings
    col_w = Inches(2.95)
    findings = [
        ("Finding 1: Camouflage Fails", "Encrypted DNS cannot hide in the QUIC crowd. Tree models achieve >94% same-network accuracy and >94.5% on realistic 8:4:4:2:2:1 traffic mixtures.", C_NAVY),
        ("Finding 2: Size Invariance", "Packet size sequence is carrier-invariant (only 1.1% cross-ISP drop). Timing features provide marginal intra-ISP gains but suffer domain collapse.", C_TEAL),
        ("Finding 3: ISP Awareness", "Models trained without domain diversity collapse (47–64% drop). Real-world defensive and surveillance systems require multi-vantage point training.", C_RED),
    ]
    for i, (title, desc, col) in enumerate(findings):
        x = Inches(0.35 + i * 3.17)
        add_rect(slide, x, Inches(1.10), col_w, Inches(0.26), col)
        add_textbox(slide, title, x+Inches(0.06), Inches(1.12), col_w-Inches(0.12), Inches(0.22),
                    font_size=8.5, bold=True, color=C_WHITE)
        add_rect(slide, x, Inches(1.36), col_w, Inches(1.10), C_BG_BOX)
        add_textbox(slide, desc, x+Inches(0.08), Inches(1.42), col_w-Inches(0.16), Inches(0.98),
                    font_size=8.5, color=C_BODY, wrap=True)

    # Contributions Card
    add_rect(slide, Inches(0.35), Inches(2.56), Inches(4.45), Inches(0.26), C_NAVY)
    add_textbox(slide, "RESEARCH CONTRIBUTIONS", Inches(0.45), Inches(2.58), Inches(4.2), Inches(0.22),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_rect(slide, Inches(0.35), Inches(2.82), Inches(4.45), Inches(1.45), C_BG_ROW)
    contribs = [
        "First multi-protocol capture engine for 6 modern protocols across Jio & Airtel.",
        "Created 95,638 packet benchmark with 0 DOT and 0 payload leakage.",
        "Demonstrated packet size invariance vs. timing drift under domain shift.",
        "Evaluated realistic deployment reliability (88.16% recall at <0.5% FPR)."
    ]
    for i, c in enumerate(contribs):
        add_textbox(slide, f"✓  {c}", Inches(0.45), Inches(2.88 + i * 0.33), Inches(4.25), Inches(0.30),
                    font_size=8.0, color=C_BODY, wrap=True)

    # References Card
    add_rect(slide, Inches(5.20), Inches(2.56), Inches(4.45), Inches(0.26), C_NAVY)
    add_textbox(slide, "KEY REFERENCES", Inches(5.30), Inches(2.58), Inches(4.2), Inches(0.22),
                font_size=8.5, bold=True, color=C_LTEAL)
    add_rect(slide, Inches(5.20), Inches(2.82), Inches(4.45), Inches(1.45), C_BG_BOX)
    refs = [
        "[1] Csikor et al., 'Privacy of DNS-over-HTTPS: Requiem for a Dream?', IEEE EuroS&P, 2021. (Base Paper)",
        "[2] Moure-Garrido et al., 'Fingerprinting Encrypted DNS in QUIC', IEEE MSWiM, 2025.",
        "[3] RFC 9250 (DNS over Dedicated QUIC Connections), IETF, 2022.",
        "[4] RFC 9114 (HTTP/3), IETF, 2022.  •  doh_docker framework."
    ]
    for i, r in enumerate(refs):
        add_textbox(slide, r, Inches(5.30), Inches(2.88 + i * 0.33), Inches(4.25), Inches(0.30),
                    font_size=8.0, color=C_BODY, wrap=True)

    # Evaluation note
    add_textbox(slide, "IIIT Allahabad  •  Department of Information Technology  •  B.Tech Thesis Defense",
                Inches(0.35), Inches(4.90), Inches(9.30), Inches(0.24),
                font_size=8.5, bold=True, color=C_NAVY, align=PP_ALIGN.CENTER)

def main():
    print("Loading presentation template:", TEMPLATE_PATH)
    prs = Presentation(TEMPLATE_PATH)
    print(f"Total slides in template: {len(prs.slides)}")

    print("Updating Slide 2 (Problem Statement)...")
    build_slide2(prs.slides[1])

    print("Updating Slide 3 (Mid-Sem vs Final)...")
    build_slide3(prs.slides[2])

    print("Updating Slide 4 (Dataset Collection)...")
    build_slide4(prs.slides[3])

    print("Updating Slide 5 (Dataset Composition)...")
    build_slide5(prs.slides[4])

    print("Updating Slide 6 (Same-Network Results)...")
    build_slide6(prs.slides[5])

    print("Updating Slide 7 (Cross-Network Generalization)...")
    build_slide7(prs.slides[6])

    print("Updating Slide 8 (Balanced vs Controlled Imbalance)...")
    build_slide8(prs.slides[7])

    print("Updating Slide 9 (All ML Models Overall)...")
    build_slide9(prs.slides[8])

    print("Updating Slide 10 (Detection & Low-FPR Analysis)...")
    build_slide10(prs.slides[9])

    print("Updating Slide 11 (Feature Importance)...")
    build_slide11(prs.slides[10])

    print("Updating Slide 12 (Feature Ablation Across Networks)...")
    build_slide12(prs.slides[11])

    print("Updating Slide 13 (Research Findings & Contributions)...")
    build_slide13(prs.slides[12])

    print("Preserving Slide 1 (Title) and Slide 14 (Thank You) from template.")

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    prs.save(OUTPUT_PATH)
    print("✅ Successfully generated final presentation at:", OUTPUT_PATH)

if __name__ == '__main__':
    main()
