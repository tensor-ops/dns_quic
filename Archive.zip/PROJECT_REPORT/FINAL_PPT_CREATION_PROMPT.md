# Master Prompt: Final Defense Presentation Deck Generation
**Project Title:** DNS in the QUIC Crowd: Can Modern Encrypted DNS Hide Among Encrypted Web Traffic?  
**Institution:** Indian Institute of Information Technology, Allahabad (IIIT-A)  
**Department:** Department of Information Technology  
**Team Members:**
- Kunal Singla (`IIT2023239`)
- Siddhartha Srivastava (`IIT2023504`)
- Parth Agrawal (`IIT2023506`)

---

## System Role & Instructions for the AI / Presentation Designer
You are an expert academic defense presentation designer specializing in Network Security, Encrypted Traffic Fingerprinting, and Machine Learning. Your task is to generate or refine a **14-slide academic defense slide deck** for a final B.Tech Thesis evaluation.

### Mandatory Ground Rules & Design Language
1. **Color Palette:**
   - Primary Dark / Headers: Navy `#14284B`
   - Primary Accent / Highlights: Deep Teal `#0F7C8A`
   - Secondary Accent / Badges: Soft Cyan / Light Teal `#8FD3DB`
   - Body Text: Charcoal / Dark Slate `#1E293B`
   - Backgrounds / Cards: Crisp White `#FFFFFF` & Ice Grey `#F1F5F9`
   - Alert / Degradation: Crimson Red `#DC2626`
   - Success / High Accuracy: Forest Green `#16A34A`
2. **Typography & Layout:**
   - 16:9 Widescreen layout.
   - Clean card-based visual hierarchy: Top header band, subtitle, 2 to 4 structured content cards/tables per slide, and bottom takeaway strip.
   - Zero wall-of-text: Use quantitative metric badges, comparative matrices, and concise bullet points.
3. **No-Cheat Classification Rules:**
   - Explicitly highlight that **IP addresses, port numbers (443/853), SNI headers, and payload bytes are strictly stripped**.
   - Features used: $(L_i, L_{i-1}, \Delta T_i, \Delta T_{i-1})$ — packet sizes and inter-arrival gaps only.

---

## Detailed 14-Slide Presentation Deck Specification

### Slide 1: Title Slide (Evaluation & Defense)
- **Header:** Indian Institute of Information Technology, Allahabad — Department of Information Technology
- **Title:** **DNS in the QUIC Crowd**
- **Subtitle:** *Can Modern Encrypted DNS Hide Among Encrypted Web Traffic?*
- **Team Roster:**
  - Kunal Singla (`IIT2023239`)
  - Siddhartha Srivastava (`IIT2023504`)
  - Parth Agrawal (`IIT2023506`)
- **Visuals:** Official IIITA Crest Logo (`Picture 1` in template).

### Slide 2: Problem Statement & Research Objectives
- **Central Research Question:** Across today's 6 modern traffic classes (DoH, DoH/3, DoQ, HTTPS, HTTP/3, QUIC), can we separate DNS from web traffic using ONLY visible packet-level metadata with zero payload inspection?
- **The Threat Model:** Passive on-path observer monitoring encrypted links. While TLS 1.3 & QUIC hide payloads, packet lengths and arrival timings remain exposed.
- **Four Core Research Objectives (Cards):**
  - **RQ1 (Detection):** Can packet size & timing separate all 6 protocol classes with >90% accuracy?
  - **RQ2 (Generalization):** Does a model trained on Jio transfer to Airtel, or does domain shift collapse performance?
  - **RQ3 (Feature Mechanics):** Does packet size or timing drive classification, and which is carrier-invariant?
  - **RQ4 (Reliability):** Can an observer detect encrypted DNS while keeping web false alarms under 0.5%?
- **Features Used:** $L_i$ (Current Size), $L_{i-1}$ (Previous Size), $\Delta T_i$ (Current Time Gap), $\Delta T_{i-1}$ (Previous Time Gap).
- **Strictly Stripped:** Ports (443/853), IPs, SNI, Payload.

### Slide 3: Mid-Sem Pilot vs. Final Accomplishments
- **Mid-Sem Pilot (Binary Baseline):**
  - Single pair: DoH/3 vs. HTTP/3.
  - Controlled lab testbed (~96% accuracy).
  - Showed tree models outperform linear due to non-linear boundaries.
  - Single ISP, balanced artificial data.
- **Final Work (This Defense):**
  - 6 full protocols: DoQ, DoH/3, DoH, HTTPS, HTTP/3, Bare QUIC.
  - Multi-vantage point: Live production captures from Jio & Airtel across 2 cities.
  - Massive dataset: 95,638 cleaned packets, 0 DOT leakage, 0 nulls.
  - Realistic imbalance evaluation: 8:4:4:2:2:1 ratio (42,000 packets).
  - Cross-network domain shift evaluation: Jio ↔ Airtel transferability.
  - Invariance ablation: Isolated packet size vs. timing under carrier jitter.

### Slide 4: Real-World Dataset Collection & Experimental Rigor
- **6 Protocol Drivers:**
  - `DoQ (RFC 9250)`: Native UDP/853 client querying AdGuard & NextDNS.
  - `DoH/3 (RFC 9114)`: UDP/443 client querying Cloudflare Anycast (`104.16.248.249`).
  - `DoH (RFC 8484)`: TCP/443 queries to Google & Cloudflare over TLS 1.3.
  - `HTTPS Web`: TCP/443 page downloads from Alexa Top-1M domains.
  - `HTTP/3 Web`: UDP/443 web asset streams with h3 ALPN negotiation.
  - `QUIC Media/Data`: UDP/443 non-DNS bulk transport sessions.
- **4 Live Physical Vantage Points:**
  - Prayagraj Airtel (Fiber): 55,239 packets
  - Prayagraj Jio (4G/5G): 26,000 packets
  - Tumsar Airtel (Broadband): 8,399 packets
  - Mirzapur Jio (Cellular): 6,000 packets
- **Capture Infrastructure:** Live kernel TAP interface (`wlo1`) with microsecond pcap timestamping.

### Slide 5: Dataset Composition Across Networks (Table)
| Traffic Class | Protocol Type | Transport | Jio Total | Airtel Total | Ratio Set (8:4:4:2:2:1) | FULL COMBINED |
|---|---|---|:---:|:---:|:---:|:---:|
| **HTTPS Web** | Standard Web | TCP / 443 | 9,000 | 13,692 | 16,000 (38.1%) | **22,692** |
| **HTTP/3 Web** | QUIC Web | UDP / 443 | 7,000 | 13,021 | 8,000 (19.0%) | **20,021** |
| **DoH (RFC 8484)** | Encrypted DNS | TCP / 443 | 5,000 | 10,377 | 8,000 (19.0%) | **15,377** |
| **DoH/3 (RFC 9114)** | QUIC DNS | UDP / 443 | 3,000 | 10,405 | 4,000 (9.5%) | **13,405** |
| **DoQ (RFC 9250)** | Native QUIC DNS | UDP / 853 | 3,000 | 9,642 | 4,000 (9.5%) | **12,642** |
| **QUIC Media/Data** | Bare QUIC | UDP / 443 | 5,000 | 6,501 | 2,000 (4.8%) | **11,501** |
| **TOTALS** | **6 Classes** | **TCP + UDP** | **32,000** | **63,638** | **42,000** | **95,638** |

### Slide 6: Same-Network Results (70/15/15 Split + 5-Fold CV)
- **Top Metrics:** Full Best = 94.50% (RF), Jio Best = 95.21% (RF), Airtel Best = 94.23% (XGB), Ratio Best = 94.54% (XGB).
- **Benchmark Table:**
  - Random Forest: Full 94.50%, Jio 95.21%, Airtel 94.09%, Ratio 94.51%, CV 92.28% ± 0.26%, Time 2.91s
  - XGBoost: Full 93.99%, Jio 94.83%, Airtel 94.23%, Ratio 94.54%, CV 91.91% ± 0.35%, Time 2.38s
  - Decision Tree: Full 91.98%, Jio 95.10%, Airtel 91.78%, Ratio 92.78%, CV 89.49% ± 0.59%, Time 0.27s
  - KNN: Full 91.11%, Jio 93.17%, Airtel 91.32%, Ratio 91.46%, CV 88.47% ± 0.43%, Time 0.02s
  - MLP (Scaled): Full 84.94%, Jio 94.67%, Airtel 78.32%, Ratio 82.56%, CV 40.33%, Time 47.85s
  - Logistic Regression: Full 29.21%, Jio 27.19%, Airtel 34.13%, Ratio 38.21% (Fails)
  - Linear SVM: Full 27.14%, Jio 33.44%, Airtel 30.08%, Ratio 38.10% (Fails)
- **Takeaway:** Linear models fail completely due to non-linear feature overlap; tree ensembles dominate.

### Slide 7: Cross-Network Generalization (Domain Shift Analysis)
- **The Finding:** Severe performance collapse when naively transferring across carriers.
- **Jio → Airtel (28.8k train → 63.6k test):**
  - Random Forest: 30.74% (-63.8% drop)
  - Decision Tree: 30.26% (-64.7% drop)
  - MLP: 28.20% (-66.8% drop)
  - XGBoost: 27.85% (-66.9% drop)
- **Airtel → Jio (57.3k train → 32.0k test):**
  - KNN: 46.08% (-47.1% drop)
  - MLP: 42.64% (-40.0% drop)
  - Random Forest: 41.04% (-53.1% drop)
- **Synthesis:** Airtel → Jio generalizes ~50% better due to larger, more diverse training corpus. Carrier timing jitter is the primary culprit.

### Slide 8: Balanced vs. Controlled Imbalanced Traffic
- **Table A (Balanced 95k):** Equal distribution, pure protocol discriminability. Best = 94.50% (RF).
- **Table B (Realistic Ratio 42k, 8:4:4:2:2:1):**
  - HTTPS Web (38.1%), HTTP/3 Web (19.0%), DoH (19.0%), DoH/3 (9.5%), DoQ (9.5%), QUIC Data (4.8%).
  - Best = 94.54% (XGBoost), Macro-F1 = 0.9270.
- **Operational Reality:** Classifiers retain >94.5% accuracy without base-rate collapse even when DNS is outnumbered 8:1 by web traffic.

### Slide 9: ML Models & Overall Results (Combined Multi-ISP Dataset)
- **Architecture Benchmarking on 95,638 Samples:**
  - Random Forest: Test Acc 94.50%, Precision 94.02%, Recall 94.45%, Macro-F1 0.9413, Weighted F1 0.9451
  - XGBoost: Test Acc 93.99%, Precision 93.60%, Recall 93.92%, Macro-F1 0.9363, Weighted F1 0.9401
  - Decision Tree: Test Acc 91.98%, Precision 91.36%, Recall 91.83%, Macro-F1 0.9146, Weighted F1 0.9196
  - K-Nearest Neighbors: Test Acc 91.11%, Precision 90.81%, Recall 90.64%, Macro-F1 0.9061, Weighted F1 0.9114
  - MLP Neural Network: Test Acc 84.94%, Precision 77.43%, Recall 75.74%, Macro-F1 0.8356, Weighted F1 0.7772
  - Logistic Regression: Test Acc 29.21%, Macro-F1 0.1657
  - Linear SVM: Test Acc 27.14%, Macro-F1 0.1413

### Slide 10: Detailed Detection Performance & Low-FPR Analysis
- **Binary Classification (Cluster A: Encrypted DNS vs. Cluster B: Web Traffic):**
  - Binary Accuracy: **96.89%** | Precision: **97.29%** | Recall: **95.47%** | Balanced F1: **0.9638**
- **Binary Confusion Matrix (Test Set: 19,128 Samples):**
  - True Negatives (Web Correctly Ignored): **10,623**
  - False Positives (Web Misclassified as DNS): **220** (FPR = 2.03%)
  - False Negatives (DNS Missed): **375**
  - True Positives (DNS Intercepted): **7,910**
- **Low-FPR Operating Points (Adversary Surveillance Regime):**
  - At Target FPR $\le 1.0\%$ (Achieved: 0.98%): **Recall = 93.06%**, **Precision = 98.64%**
  - At Target FPR $\le 0.5\%$ (Achieved: 0.47%): **Recall = 88.16%**, **Precision = 99.31%**
  - At Target FPR $\le 0.2\%$ (Achieved: 0.19%): **Recall = 78.40%**, **Precision = 99.68%**
  - At Target FPR $\le 0.1\%$ (Achieved: 0.08%): **Recall = 68.20%**, **Precision = 99.85%**
- **RQ4 Answer:** At less than 1 false alarm per 200 web packets (<0.5% FPR), the adversary intercepts 88.16% of encrypted DNS queries.

### Slide 11: Feature Importance Analysis
- **Feature Weights (Gini Importance & SHAP):**
  - Current Packet Size ($L_i$): **52.4%** — QUIC Initial $\ge 1200$ B vs. DNS queries 60–180 B vs. Web MTU 1460 B.
  - Previous Packet Size ($L_{i-1}$): **30.8%** — Request $\to$ response transition dynamics.
  - Current Time Gap ($\Delta T_i$): **11.1%** — Local RTT signature; drifts across carriers.
  - Previous Time Gap ($\Delta T_{i-1}$): **5.7%** — Weakest signal; vulnerable to queuing jitter.
- **Physical Takeaway:** Packet sizes provide **83.2% of total discriminative power**.

### Slide 12: Feature Ablation Across Networks (Size vs. Timing)
- **Comparison Table:**
  - All Features: Same-Net 94.50%, Cross-Net 90.40%, Drop 4.1%
  - **Size-Only ($L_i, L_{i-1}$):** Same-Net 91.20%, Cross-Net 90.10%, **Drop 1.1% (Near-Zero Carrier Drift!)**
  - **Timing-Only ($\Delta T_i, \Delta T_{i-1}$):** Same-Net 52.40%, Cross-Net 41.10%, **Drop 11.3% (Severe Collapse)**
- **Critical Insight:** Packet size sequence is the **carrier-invariant protocol anchor**. Timing features cause cross-carrier collapse due to propagation differences.

### Slide 13: Research Findings, Contributions & References
- **Three Core Findings:**
  1. *Camouflage Failure:* Encrypted DNS cannot hide in the QUIC crowd (>94% same-net, >94.5% ratio-weighted).
  2. *Size Invariance:* Packet size transfers with only 1.1% degradation.
  3. *Domain Shift:* Uncalibrated timing features collapse by 47–64%.
- **Research Contributions:** Multi-protocol capture engine, 95k+ clean packet dataset, domain shift evaluation, and low-FPR surveillance benchmarking.
- **References:** Csikor et al. (EuroS&P 2021), Moure-Garrido et al. (MSWiM 2025), RFC 9250 (DoQ), RFC 9114 (HTTP/3).

### Slide 14: Thank You & Defense Q&A
- Title: **THANK YOU**
- Subtitle: *Questions & Discussion*
- Presenters: Kunal Singla, Siddhartha Srivastava, Parth Agrawal (IIIT Allahabad)
